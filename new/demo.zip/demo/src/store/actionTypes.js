export const INPUT_NAME_VALUE="change_name_value";
export const INPUT_GENDER_ITEM="add_gender_item";
export const INPUT_AGE_ITEM="delete_age_item";
export const INPUT_HOBBY_ITEM="delete_hobby_item";
export const ADD_MESSAGE_VALUE="add_message";
export const DELETE_MESSAGE_ITEM="delete_message_item";